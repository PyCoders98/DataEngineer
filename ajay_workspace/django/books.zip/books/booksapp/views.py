from typing import Any
from django.shortcuts import render, redirect
from django.views.generic import ListView, TemplateView
from .models import *
from .forms import *
from django.http import JsonResponse

class Home(ListView):
    template_name = "index.html"
    model = Details
    context_object_name = "data"

    def get_context_data(self, **kwargs: Any):
        context = super().get_context_data(**kwargs)
        context["form"] = DetailForms()
        return context

    def post(self, request):
        response_data = {}
        form = DetailForms(request.POST)
        if form.is_valid():
            response_data['name'] = request.POST.get('name')
            response_data['age'] = request.POST.get('age')
            response_data['phone'] = request.POST.get('phone')
            form.save()
            return JsonResponse(response_data)
        else:
            context = self.get_context_data()
            context["form"] = form
            return self.render_to_response(context)
